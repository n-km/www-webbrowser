# www-webbrowser
<img src=".pictures/www-webbrowser.png">

## What is "www-webbrowser"
It's like a Filesearch. You can write commands in the input-field and so you can get to other HTML sites. It's simply.

<h2> Go to the<a href="https://n-km.github.io/www-webbrowser/22-gg/"> Website </a>!</h2>
<br>
<h2>Available Commands:</h2>
      
      -Abstimmung
<p></p>
      
      -admin
      
<p></p>

        -bing

<p></p>
      
      -camera

<p></p>

        -txtcgpt

<p></p>
        
        -cloud

<p></p>
       
        -editor

<p></p>
       
        -fastboot

<p></p>
       
        -filemanager

<p></p>

        -google

<p></p>
      
        -help

<p></p>
     
        -launcher

<p></p>
       
        -mbview

<p></p>
      
        -mobile

<p></p>
       
        -papp

<p></p>
      
        -playstore
<p></p>

        -radio
      
<h2>Backup Downloads:</h2>
<h3>Version 1.0:</h3>
<a href="https://raw.githubusercontent.com/n-km/www-webbrowser/main/.backups/v.1.0.zip">Download</a>